#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
   

  

int main()
{
 
  
  int sockfd,newsockfd,portno,n;
  char buffer[255];
  struct sockaddr_in serv_addr,cli_addr;
  socklen_t clilen;
  
  sockfd=socket(AF_INET,SOCK_DGRAM,0);
  
  if(sockfd<0)
  {
    printf("error opening socker\n");
    exit(1);
  }
  
  bzero((char *) &serv_addr,sizeof(serv_addr));
  
  portno=7777;
  
  serv_addr.sin_family=AF_INET;
  inet_pton(AF_INET,"127.0.0.3",&(serv_addr.sin_addr));
  serv_addr.sin_port=htons(portno);
  
  if(bind(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr))<0)
        {
           printf("Bnding Failed\n");
           exit(1);
        }
 clilen=sizeof(serv_addr);
 
 while(1){
 bzero(buffer,255);
 
 
 
 n=recvfrom(sockfd,buffer,255,0,(struct sockaddr *) &serv_addr,&clilen);
 if(n<0)
 {
   printf("error from recieving\n");
  
  exit(1);
 }
 
  strcpy(buffer,"127.0.0.4");
 
 
 n=sendto(sockfd,buffer,strlen(buffer),0,(struct sockaddr *) &serv_addr,clilen);
 if(n<0)
 {
   printf("error in sending\n");
   exit(1);
 
 }
 }
 return 0;       
}
