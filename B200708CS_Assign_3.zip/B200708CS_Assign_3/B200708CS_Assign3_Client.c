#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>

int SEARCH_CACHE(char cache[255][255],char *buffer)
{
   int buffer_len=strlen(buffer);
   buffer_len=buffer_len-1;
   
   for(int a=0;a<255;a++)
  {
    int tmp=strncmp(buffer,cache[a],buffer_len);
    if(tmp==0)
    {
      memset(buffer,0,255);
      for(int b=0;b<strlen(cache[a])-buffer_len;b++)
           buffer[b]=cache[a][b+buffer_len+1];
      return 1;
    }
  }
  
  return 0;
}

void STORE_IN_CACHE(char cache[255][255],char *buffer)
{
   for(int a=0;a<255;a++)
   {
     if(cache[a][0]=='0')
      {
        strcpy(cache[a],buffer);
        return;
      }
   }
}

int main()
{
 
 
  
  struct sockaddr_in serv_addr;
  struct hostent *server;
  int sockfd,newsockfd,portno,n,clilen;
  char buffer[255],cache[255][255];
  portno=9898;
  
  sockfd=socket(AF_INET,SOCK_DGRAM,0);
  
  if(sockfd<0)
  {
    printf("error opening socker\n");
    exit(1);
  }
  
  server=gethostbyname("127.0.0.1");
  if(server==NULL)
  {
    printf("error, no such host\n");
  } 
    bzero((char *) &serv_addr,sizeof(serv_addr));
    serv_addr.sin_family=AF_INET;
    
    bcopy((char *) server->h_addr,(char *) &serv_addr.sin_addr.s_addr,server->h_length);
    serv_addr.sin_port=htons(portno);
  
  
 clilen=sizeof(serv_addr);
 
 for(int a=0;a<255;a++)
    for(int b=0;b<255;b++)
        cache[a][b]='0';
 
 while(1){
 bzero(buffer,255);
 
 printf("enter a string as input:");
 fgets(buffer,255,stdin);
 
 if(strncmp(buffer,"exit",4)==0)
 return 0;
 
 /*int res=SEARCH_CACHE(cache,buffer);
 if(res)
 {
   printf("address found in cache: %s\n",buffer);
   
 }
 
 else{*/
 
 n=sendto(sockfd,buffer,strlen(buffer),0,(struct sockaddr *) &serv_addr,clilen);
 if(n<0)
 {
   printf("error in sending\n");
   exit(1);
 
 }
 
/* char un_address[255];
 memset(un_address,0,255);
 
 int len=strlen(buffer);
 len=len-1;
 strncpy(un_address,buffer,len);*/
 
 bzero(buffer,255);
 n=recvfrom(sockfd,buffer,255,0,(struct sockaddr *) &serv_addr,&clilen);
 if(n<0 || n==0)
 {
   printf("error from recieving\n");
  
  exit(1);
 }
 printf("server response is:%s\n",buffer);
 
/* strcat(un_address,"=");
 strcat(un_address,buffer);
 
 
 STORE_IN_CACHE(cache,un_address);*/
 
 }
 
 
 close(sockfd);
 return 0;       
}
