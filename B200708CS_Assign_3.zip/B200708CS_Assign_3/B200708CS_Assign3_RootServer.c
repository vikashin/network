#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>  ///for inet_pton


int main()
{
 
 
  int sockfd,portno,n;
  char buffer[255];
  struct sockaddr_in serv_addr;
  socklen_t clilen;
  
  sockfd=socket(AF_INET,SOCK_DGRAM,0);
  
  if(sockfd<0)
  {
    printf("error opening socker\n");
    exit(1);
  }
  
  bzero((char *) &serv_addr,sizeof(serv_addr));
  
  portno=8888;
  
  serv_addr.sin_family=AF_INET;
  //serv_addr.sin_addr.s_addr=inet_addr("127.0.0.2");
  serv_addr.sin_port=htons(portno);
  inet_pton(AF_INET,"127.0.0.2",&(serv_addr.sin_addr));
  
  if(bind(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr))<0)
        {
           printf("Bnding Failed\n");
           exit(1);
        }
 clilen=sizeof(serv_addr);
 while(1){
 bzero(buffer,255);
 n=recvfrom(sockfd,buffer,255,0,(struct sockaddr *) &serv_addr,&clilen);
 if(n<0)
 {
   printf("error from recieving\n");
  
  exit(1);
 }
 
 if(n==0)
 exit(1);
 
 printf("client input is:%s\n",buffer); 
 
 memset(buffer,0,255);
 strcpy(buffer,"127.0.0.3");
 printf("%s\n",buffer);
 n=sendto(sockfd,buffer,strlen(buffer),0,(struct sockaddr *) &serv_addr,clilen);
 if(n<0)
 {
   printf("error in sending\n");
   exit(1);
 
 }
 }
 return 0;       
}
