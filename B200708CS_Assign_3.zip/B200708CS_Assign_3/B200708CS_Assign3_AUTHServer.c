#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<arpa/inet.h>
   
int SEARCH_ADDRESS(char database[255][255],char *buffer)
{
  int buffer_len=strlen(buffer);
  
  buffer_len=buffer_len-1;
  
  for(int a=0;a<255;a++)
  {
    int tmp=strncmp(buffer,database[a],buffer_len);
    if(tmp==0)
    {
      memset(buffer,0,255);
      for(int b=0;b<strlen(database[a])-buffer_len;b++)
           buffer[b]=database[a][b+buffer_len+1];
        
      return 1;
    }
  }
  
  printf("NOT found\n");
  return 0;
  
}
  

int main()
{
 
  
  int sockfd,newsockfd,portno,n;
  char buffer[255],database[255][255];
  struct sockaddr_in serv_addr;
  socklen_t clilen;
  
  sockfd=socket(AF_INET,SOCK_DGRAM,0);
  
  if(sockfd<0)
  {
    printf("error opening socker\n");
    exit(1);
  }
  
  bzero((char *) &serv_addr,sizeof(serv_addr));
  
  portno=6666;
  
  serv_addr.sin_family=AF_INET;
 inet_pton(AF_INET,"127.0.0.4",&(serv_addr.sin_addr));
  serv_addr.sin_port=htons(portno);
  
  if(bind(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr))<0)
        {
           printf("Bnding Failed\n");
           exit(1);
        }
 clilen=sizeof(serv_addr);
 bzero(buffer,255);
 
 for(int a=0;a<255;a++)                                                       ///initialize database as -1;
   for(int b=0;b<255;b++)
        database[a][b]='0';  
 
 strcpy(database[2],"www.india.com=123.234.123.345");
 strcpy(database[6],"www.google.com=8.8.8.8");
 strcpy(database[3],"www.jahnu.com=2.2.2.2");
 while(1){
 
 n=recvfrom(sockfd,buffer,255,0,(struct sockaddr *) &serv_addr,&clilen);
 if(n<0)
 {
   printf("error from recieving\n");
  
  exit(1);
 }
 
  int res=SEARCH_ADDRESS(database,buffer);
 
 if(res){
 
 n=sendto(sockfd,buffer,255,0,(struct sockaddr *) &serv_addr,clilen);
 if(n<0)
 {
   printf("error in sending\n");
   exit(1);
 
 }
 
 printf("server:%s\n",buffer);
 
 //} end while loop
 //close(sockfd);
 }
 else
 return 0;
 }
 
 return 0;       
}
