#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<arpa/inet.h>
   
   
void STORE_IN_CACHE(char cache[255][255],char *buffer)
{
   for(int a=0;a<255;a++)
   {
     if(cache[a][0]=='0')
      {
        strcpy(cache[a],buffer);
        return;
      }
   }
}


int SEARCH_ADDRESS(char database[255][255],char *buffer)
{
  int buffer_len=strlen(buffer);
  
  buffer_len=buffer_len-1;
  
  for(int a=0;a<255;a++)
  {
    int tmp=strncmp(buffer,database[a],buffer_len);
    if(tmp==0)
    {
      memset(buffer,0,255);
      for(int b=0;b<strlen(database[a])-buffer_len;b++)
           buffer[b]=database[a][b+buffer_len+1];
        
      return 1;
    }
  }
  
  printf("NOT found\n");
  return 0;
  
}
  

int main()
{
 
  
  int sockfd,newsockfd,portno,n;
  char buffer[255],cache[255][255];
  struct sockaddr_in serv_addr,cli_addr;
  socklen_t clilen;
  
  sockfd=socket(AF_INET,SOCK_DGRAM,0);
  
  if(sockfd<0)
  {
    printf("error opening socker\n");
    exit(1);
  }
  
  bzero((char *) &serv_addr,sizeof(serv_addr));
  
  portno=9898;
  
  serv_addr.sin_family=AF_INET;
  serv_addr.sin_addr.s_addr=INADDR_ANY;
  serv_addr.sin_port=htons(portno);
  
  if(bind(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr))<0)
        {
           printf("Bnding Failed\n");
           exit(1);
        }
 clilen=sizeof(serv_addr);
 bzero(buffer,255);
 
 for(int a=0;a<255;a++)                                                       ///initialize database as -1;
   for(int b=0;b<255;b++)
        cache[a][b]='0';  
 
 //strcpy(database[2],"www.india.com=123.234.123.345");
 //strcpy(database[6],"www.google.com=8.8.8.8");
  while(1){
 
 n=recvfrom(sockfd,buffer,255,0,(struct sockaddr *) &serv_addr,&clilen);
 if(n<0)
 {
   printf("error from recieving\n");
  
  exit(1);
 }
 
  int res=SEARCH_ADDRESS(cache,buffer);
 
 if(res){
 n=sendto(sockfd,buffer,strlen(buffer),0,(struct sockaddr *) &serv_addr,clilen);
 if(n<0)
 {
   printf("error in sending\n");
   exit(1);
 
 }
 
 printf("server:%s\n",buffer);
 
 //} end while loop
 //close(sockfd);
 }
 else   //search in root server
 {
   struct sockaddr_in client;
  struct hostent *server;
  int sockfd1,portno1,n1,clilen1;
  char buffer1[255];
  portno1=8888;
  
  sockfd1=socket(AF_INET,SOCK_DGRAM,0);
  
  if(sockfd1<0)
  {
    printf("error opening socker\n");
    exit(1);
  }
  
  server=gethostbyname("127.0.0.2");
  if(server==NULL)
  {
    printf("error, no such host\n");
  } 
    bzero((char *) &client,sizeof(client));
    serv_addr.sin_family=AF_INET;
    
    bcopy((char *) server->h_addr,(char *) &client.sin_addr.s_addr,server->h_length);
    client.sin_port=htons(portno1);
    clilen1=sizeof(client);
    
    memset(buffer1,0,255);
    strcpy(buffer1,buffer);
    
    n1=sendto(sockfd1,buffer1,strlen(buffer1),0,(struct sockaddr *) &client,clilen1);
   if(n1<0)
  {
   printf("error in sending\n");
   exit(1); 
  }
  
  memset(buffer1,0,255);
  
  n1=recvfrom(sockfd1,buffer1,255,0,(struct sockaddr *) &client,&clilen1);
 if(n<0 || n==0)
 {
   printf("error from recieving\n");
  
  exit(1);
 }
 printf("server response is:%s\n",buffer1);
 
 //for TLD SERVER
 
  struct sockaddr_in client_tld;
  struct hostent *server_tld;
  int sockfd2,portno2,n2,clilen_tld;
  char buffer2[255];
  portno2=7777;
  
  sockfd2=socket(AF_INET,SOCK_DGRAM,0);
  
  if(sockfd2<0)
  {
    printf("error opening socker\n");
    exit(1);
  }
  
   memset(buffer2,0,255);
   strcpy(buffer2,buffer1);
  
    
    client_tld.sin_family = AF_INET;
    client_tld.sin_port = htons(7777);
    inet_pton(AF_INET,"127.0.0.3",&(client_tld.sin_addr));
    clilen_tld=sizeof(client_tld);
    
    
    
    
    n2=sendto(sockfd2,buffer,255,0,(struct sockaddr *) &client_tld,clilen_tld);
   if(n2<0)
  {
   printf("error in sending for tld\n");
   exit(1); 
  }
  
  memset(buffer2,0,255);
  
  n2=recvfrom(sockfd2,buffer2,255,0,(struct sockaddr *) &client_tld,&clilen_tld);
 if(n2<0 || n2==0)
 {
   printf("error from recieving\n");
  
  exit(1);
 }
 printf("tld server response is:%s\n",buffer2);
 
 ///for autheric server
 struct sockaddr_in client_auth;
  struct hostent *server_auth;
  int sockfd3,portno3,n3,clilen_auth;
  char buffer3[255];
  portno3=6666;
  
  sockfd3=socket(AF_INET,SOCK_DGRAM,0);
  
  if(sockfd3<0)
  {
    printf("error opening socker\n");
    exit(1);
  }
  
   memset(buffer3,0,255);
   
  
    
    client_auth.sin_family = AF_INET;
    client_auth.sin_port = htons(portno3);
    inet_pton(AF_INET,"127.0.0.4",&(client_auth.sin_addr));
    clilen_auth=sizeof(client_auth);
    
    
    
    
    n3=sendto(sockfd3,buffer,255,0,(struct sockaddr *) &client_auth,clilen_auth);
   if(n3<0)
  {
   printf("error in sending for tld\n");
   exit(1); 
  }
  
  
  
  n3=recvfrom(sockfd3,buffer3,255,0,(struct sockaddr *) &client_auth,&clilen_auth);
 if(n3<0 || n3==0)
 {
   printf("error from recieving\n");
  
  exit(1);
 }
 printf("server response is:%s\n",buffer3);
 
 //after receiving ip addreess
 
 char un_address[255];
 memset(un_address,0,255);
 
 int len=strlen(buffer);
 len=len-1;
 strncpy(un_address,buffer,len);
 
 strcat(un_address,"=");
 strcat(un_address,buffer3);
 
 
 STORE_IN_CACHE(cache,un_address);
 
 printf("%s\n",buffer3);
 
 n=sendto(sockfd,buffer3,strlen(buffer3),0,(struct sockaddr *) &serv_addr,clilen);
 if(n<0)
 {
   printf("error in sending\n");
   exit(1);
 
 }
 
 printf("server:%s\n",buffer);
 
 }
 }
 return 0;       
}
